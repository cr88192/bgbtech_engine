#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int main()
{
	printf("OK\n");
	return(0);
}
