#include <stdio.h>

int main()
{
	printf("OK\n");
	return(0);
}
