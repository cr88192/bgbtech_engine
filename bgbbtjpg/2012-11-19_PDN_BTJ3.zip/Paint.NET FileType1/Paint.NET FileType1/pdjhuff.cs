﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BGBTechBTJ
{
    class PDJHUFF
    {
        //Decoder

        public static int NextByte(PDJPG_Context ctx)
        {
            int i, j;

            //	if(ctx.huff_isend)return(0xFF);
            if (ctx.huff_isend) return (0x00);

            i = ctx.huff_cs.next();
            if (i == 0xFF)
            {
                j = ctx.huff_cs.next();
                if (j!=0)
                {
                    //			printf("PDJHUFF.NextByte: Bitstream Marker %02X\n", j);
                    ctx.huff_isend = true;
                    return (0x00);
                }
            }
            return (i);
        }

        public static int InitStream(PDJPG_Context ctx, BytePtr buf)
        {
            ctx.huff_pos = 0;
            ctx.huff_isend = false;

            ctx.huff_cs = buf;
            ctx.huff_win = (uint)PDJHUFF.NextByte(ctx);
            ctx.huff_win = (uint)((ctx.huff_win << 8) + PDJHUFF.NextByte(ctx));
            ctx.huff_win = (uint)((ctx.huff_win << 8) + PDJHUFF.NextByte(ctx));
            ctx.huff_win = (uint)((ctx.huff_win << 8) + PDJHUFF.NextByte(ctx));
            return (0);
        }

        public static int ReadBit(PDJPG_Context ctx)
        {
            int i;

            i = (int)(ctx.huff_win >> (31 - ctx.huff_pos)) & 1;
            ctx.huff_pos++;
            if (ctx.huff_pos >= 8)
            {
                ctx.huff_win = (uint)((ctx.huff_win << 8) + PDJHUFF.NextByte(ctx));
                ctx.huff_pos -= 8;
            }
            return (i);
        }

        public static int ReadNBits(PDJPG_Context ctx, int n)
        {
            int i;

            if (n <= 0) return (0);

            i = (int)((ctx.huff_win >> (32 - n - ctx.huff_pos)) & ((1 << n) - 1));
            ctx.huff_pos += n;
            while (ctx.huff_pos >= 8)
            {
                ctx.huff_win = (uint)((ctx.huff_win << 8) + PDJHUFF.NextByte(ctx));
                ctx.huff_pos -= 8;
            }
            return (i);
        }

        public static ulong ReadNBitsL(PDJPG_Context ctx, int n)
        {
            ulong v;
            int i, j;

            i = n; v = 0;
            while (i > 16)
            {
                j=ReadNBits(ctx, 16);
                v += ((ulong)j) << (i-16);
                i -= 16;
            }
            j = ReadNBits(ctx, i);
            v += (ulong)j;
            
            return v;
        }

        public static void SkipNBits(PDJPG_Context ctx, int n)
        {
            ctx.huff_pos += n;
            while (ctx.huff_pos >= 8)
            {
                ctx.huff_win = (uint)((ctx.huff_win << 8) + PDJHUFF.NextByte(ctx));
                ctx.huff_pos -= 8;
            }
        }

        public static int PeekWord(PDJPG_Context ctx)
        {
            int i;
            i = (int)((ctx.huff_win >> (16 - ctx.huff_pos)) & 65535);
            return (i);
        }

        public static void WriteBit(PDJPG_Context ctx, int i)
        {
            ctx.huff_win |= (uint)(i << (31 - ctx.huff_pos));
            ctx.huff_pos++;
            if (ctx.huff_pos >= 8)
            {
                i = (int)((ctx.huff_win >> 24) & 0xFF);
                ctx.huff_ct.emit(i);
                if (i == 0xFF) ctx.huff_ct.emit(0x00);
                ctx.huff_win <<= 8;
                ctx.huff_pos -= 8;
            }
        }

        public static void WriteNBits(PDJPG_Context ctx, int v, int n)
        {
            int i, j, k;

            v &= (1 << n) - 1;

            j = ctx.huff_pos + n;
            k = (int)(ctx.huff_win + (v << (32 - j)));
            while (j >= 8)
            {
                i = (k >> 24) & 0xFF;
                ctx.huff_ct.emit(i);
                if (i == 0xFF) ctx.huff_ct.emit(0x00);
                k <<= 8;
                j -= 8;
            }
            ctx.huff_pos = j;
            ctx.huff_win = (uint)k;

            //	ctx.huff_win|=i<<((32-n)-ctx.huff_pos);
            //	ctx.huff_pos+=n;
            //	while(ctx.huff_pos>=8)
            //	{
            //		i=(ctx.huff_win>>24)&0xFF;
            //		*ctx.huff_ct++=i;
            //		if(i==0xFF)*ctx.huff_ct++=0x00;
            //		ctx.huff_win<<=8;
            //		ctx.huff_pos-=8;
            //	}
        }

        public static void WriteNBitsL(PDJPG_Context ctx, ulong val, int n)
        {
            ulong l;
            int i;

            l = val; i = n;
            while (i > 16)
            {
                WriteNBits(ctx, (int)((l >> (i - 16)) & 65535), 16);
                i -= 16;
            }
            WriteNBits(ctx, (int)(l & ((1UL << i) - 1)), i);
        }

        public static void FlushBits(PDJPG_Context ctx)
        {
            int i;
            while (ctx.huff_pos > 0)
            {
                i = (int)((ctx.huff_win >> 24) & 0xFF);
                ctx.huff_ct.emit(i);
                if (i == 0xFF) ctx.huff_ct.emit(0x00);
                ctx.huff_win <<= 8;
                ctx.huff_pos -= 8;
            }
        }

        public static void WriteString(PDJPG_Context ctx, string str)
        {
            //            char* s;
            int i;

            PDJHUFF.FlushBits(ctx);
            //            s = str;
            //            while (*s)
            //                *ctx.huff_ct++ = *s++;
            for (i = 0; i < str.Length; i++)
                ctx.huff_ct.emit(str[i]);
            ctx.huff_ct.emit(0);
        }

#if false
        public static int DecodeSymbol(PDJPG_Context ctx, int tab)
        {
            int i, j, k, l;

            //	i=PDJHUFF.PeekWord(ctx);
            //	i=(ctx.huff_win>>(16-ctx.huff_pos))&65535;
            //	i=(u16)(ctx.huff_win>>(16-ctx.huff_pos));

#if true
            i = (byte)(ctx.huff_win >> (24 - ctx.huff_pos));

            tab <<= 8;
            //	j=ctx.huff_idx[tab|k];
            //	j=ctx.huff_idx[tab|(i>>8)];
            j = ctx.huff_idx[tab | i];

#if false
            //	l=tab|j;
            //	k=ctx.huff_len[l];
            k = ctx.huff_len[tab | j];
            //	if(0)
            if (k <= 8)
            //	if(k<8)
            {
                ctx.huff_pos += k;
                //		while(ctx.huff_pos>=8)
                if (ctx.huff_pos >= 8)
                {
                    ctx.huff_win = (uint)((ctx.huff_win << 8) + PDJHUFF.NextByte(ctx));
                    ctx.huff_pos -= 8;
                }

                //		PDJHUFF.SkipNBits(ctx, k);
                return (j);
            }
#endif

            i = (ushort)(ctx.huff_win >> (16 - ctx.huff_pos));
            j = ctx.huff_idx[tab | (i >> 8)];

            while (j>=0)
            {
                l = tab | j;
                k = ctx.huff_len[l];
                if (k==0)
                {
                    //			printf("PDJHUFF.DecodeSymbol: Trap A\n");
                    break;
                }

#if true
                if ((i >> (16 - k)) != ctx.huff_code[l])
                //		if((k>=8) && (i>>(16-k))!=ctx.huff_code[l])
                {
                    j = ctx.huff_next[l];
                    //			if(!j)
                    if (j < 0)
                    {
                        //				printf("PDJHUFF.DecodeSymbol: Trap B\n");
                        break;
                    }
                    continue;
                }
#endif

                ctx.huff_pos += k;
                while (ctx.huff_pos >= 8)
                //		if(ctx.huff_pos>=8)
                {
                    ctx.huff_win = (uint)((ctx.huff_win << 8) + PDJHUFF.NextByte(ctx));
                    ctx.huff_pos -= 8;
                }

                //		PDJHUFF.SkipNBits(ctx, k);
                return (j);
            }

#endif

#if false
	i=PDJHUFF.PeekWord(ctx);
	for(j=0; j<256; j++)
	{
		k=ctx.huff_len[tab|j];
		if(!k)continue;

		if((i>>(16-k))!=ctx.huff_code[tab|j])
			continue;
		PDJHUFF.SkipNBits(ctx, k);
		return(j);
	}
#endif

            return (-1);
        }
#endif


#if true
        public static int DecodeSymbol(PDJPG_Context ctx, int tab)
        {
            //	int i, j, k, l;
            int i, j, k;

            tab <<= 8;

#if false
            i = PDJHUFF.PeekWord(ctx);
            j = ctx.huff_idx[tab | (i >> 8)];
            while (1)
            {
                l = tab | j;
                k = ctx.huff_len[l];
                //		if(!k)break;

                if ((i >> (16 - k)) != ctx.huff_code[l])
                {
                    j = ctx.huff_next[l];
                    if (!j) break;
                    continue;
                }
                PDJHUFF.SkipNBits(ctx, k);
                return (j);
            }
#endif

#if true
            i = PDJHUFF.PeekWord(ctx);
            for (j = 0; j < 256; j++)
            {
                k = ctx.huff_len[tab | j];
                if (k <= 0) continue;

                if ((i >> (16 - k)) != ctx.huff_code[tab | j])
                    continue;
                PDJHUFF.SkipNBits(ctx, k);
                return (j);
            }
#endif

            return (-1);
        }
#endif

        public static int DecodeDiffDC(PDJPG_Context ctx, int tab)
        {
            int i, j;

            i = PDJHUFF.DecodeSymbol(ctx, tab);
            j = PDJHUFF.ReadNBits(ctx, i);

            if ((j & (1 << (i - 1)))==0)
                j = (-1 << i) + j + 1;
            return (j);
        }

        public static void QuantBlock(
            PDJPG_Context ctx, ShortPtr ibuf, ShortPtr obuf, int qid)
        {
            int i;

            //	for(i=0; i<64; i++)
            //		obuf[i]=ibuf[i]/ctx.jpg_qt[qid][i];

            for (i = 0; i < 64; i++)
                obuf[i] = (ibuf[i] * ctx.jpg_qtfp[qid*64+i]) >> 12;
        }

        public static void DequantBlock(
            PDJPG_Context ctx, ShortPtr ibuf, ShortPtr obuf, int qid)
        {
            int i;
            for (i = 0; i < 64; i++)
                obuf[i] = ibuf[i] * ctx.jpg_qt[qid*64+i];
        }

#if true
        public static void QuantMegaBlock(
            PDJPG_Context ctx, ShortPtr ibuf, ShortPtr obuf, int qid)
        {
            int i, j, k, l;

            //	for(i=0; i<64; i++)
            //		obuf[i]=ibuf[i]/ctx.jpg_qt[qid][i];

            //for (i = 0; i < 128; i++)
               // obuf[i] = (ibuf[i] * ctx.jpg_qtfp[qid * 256 + i]) >> 12;

            for (i = 0; i < 64; i++)
            {
                k = (ibuf[i * 64] * ctx.jpg_qtfp[qid * 256 + 64 + i]) >> 12;
                obuf[i * 64] = k;
            }

            for (i = 1; i < 64; i++)
            {
                for (j = 0; j < 64; j++)
                {
                    k = (ibuf[j * 64 + i] * ctx.jpg_qtfp[qid * 256 + i]) >> 12;
                    obuf[j * 64 + i] = k;
                }
            }

#if true
            l = 0;
            for (i = 0; i < 4096; i++)
            {
                j = obuf[PDJPG.pdjpg_doublezigzag2[i]];
                obuf[PDJPG.pdjpg_doublezigzag2[i]] = j - l;
                l = j;
            }
#endif
        }

        public static void DequantMegaBlock(
            PDJPG_Context ctx, ShortPtr ibuf, ShortPtr obuf, int qid)
        {
            int i, j, k;

#if true
            k = 0;
            for (i = 0; i < 4096; i++)
            {
                j = ibuf[PDJPG.pdjpg_doublezigzag2[i]];
                k = k + j;
                obuf[PDJPG.pdjpg_doublezigzag2[i]] = k;
            }
#endif

            for (i = 0; i < 64; i++)
                obuf[i * 64] = obuf[i * 64] * ctx.jpg_qt[qid * 256 + 64 + i];

            for (i = 1; i < 64; i++)
            {
                for (j = 0; j < 64; j++)
                {
                    obuf[j*64+i] = obuf[j*64+i] * ctx.jpg_qt[qid * 256 + i];
                }
            }
        }
#endif

        public static int BalanceTree_r(ShortPtr nodes, ShortPtr nlen, int root, int h, int ml)
        {
            int h0, h1, h2, h3;
            int l0, l1, l2;

            if (root < 0) return (0);

            h1 = PDJHUFF.BalanceTree_r(nodes, nlen, nodes[root * 2 + 0], h + 1, ml);
            h2 = PDJHUFF.BalanceTree_r(nodes, nlen, nodes[root * 2 + 1], h + 1, ml);
            h0 = ((h1 > h2) ? h1 : h2) + 1;
            nlen[root] = (short)h0;

            if ((h + h0) <= ml)	//depth limit not exceeded
                return (h0);

            //ok, so part of the tree is too deep
            if ((h1 + 1) < h2)
            {
                l0 = nodes[root * 2 + 1];
                l1 = nodes[l0 * 2 + 1];
                nodes[l0 * 2 + 1] = nodes[l0 * 2 + 0];
                nodes[l0 * 2 + 0] = nodes[root * 2 + 0];
                nodes[root * 2 + 0] = (short)l0;
                nodes[root * 2 + 1] = (short)l1;
            }
            else if ((h2 + 1) < h1)
            {
                l0 = nodes[root * 2 + 0];
                l1 = nodes[l0 * 2 + 0];
                nodes[l0 * 2 + 0] = nodes[l0 * 2 + 1];
                nodes[l0 * 2 + 1] = nodes[root * 2 + 1];
                nodes[root * 2 + 0] = (short)l1;
                nodes[root * 2 + 1] = (short)l0;
            }
            else
            {
                //rotating would be ineffective or would make things worse...
                return (h0);
            }

            //recalc depth of modified sub-tree
            l1 = nodes[l0 * 2 + 0];
            l2 = nodes[l0 * 2 + 1];
            h1 = (l1 < 0) ? 0 : nlen[l1];
            h2 = (l2 < 0) ? 0 : nlen[l2];
            h3 = ((h1 > h2) ? h1 : h2) + 1;
            nlen[l0] = (short)h3;

            //recalc height of root node
            l1 = nodes[root * 2 + 0];
            l2 = nodes[root * 2 + 1];
            h1 = (l1 < 0) ? 0 : nlen[l1];
            h2 = (l2 < 0) ? 0 : nlen[l2];
            h0 = ((h1 > h2) ? h1 : h2) + 1;
            nlen[root] = (short)h0;

            return (h0);
        }

        public static void CalcLengths_r(ShortPtr nodes, BytePtr cl, int root, int h)
        {
            if (root < 0)
            {
                if (root == -513) return;
                cl[(-root) - 1] = (byte)h;
                return;
            }

            PDJHUFF.CalcLengths_r(nodes, cl, nodes[root * 2 + 0], h + 1);
            PDJHUFF.CalcLengths_r(nodes, cl, nodes[root * 2 + 1], h + 1);
        }

        public static int BuildLengths(IntPtr stat, int nc, BytePtr cl, int ml)
        {
            //	static short nodes[1024], nlen[512];
            //	static short roots[512], clen[512];
            //	static int cnts[512];

            short[] nodes = new short[1024];
            short[] nlen = new short[512];
            short[] roots = new short[512];
            short[] clen = new short[512];
            int[] cnts = new int[512];
            int nr, nn;
            int i, j, k, l;

            nr = 0; nn = 0;
            for (i = 0; i < nc; i++)
            {
                if (stat[i]==0) continue;
                roots[nr] = (short)(-(i + 1));
                cnts[nr] = stat[i];
                clen[nr] = 0;
                nr++;
            }

            roots[nr] = -513;
            cnts[nr] = 0;
            clen[nr] = 0;
            nr++;


            for (i = 0; i < nc; i++) cl[i] = 0;
            if (nr==0) return (-1);


            while (nr > 1)
            {
                if (cnts[0] >= cnts[1]) { j = 0; k = 1; }
                else { j = 1; k = 0; }
                for (i = 2; i < nr; i++)
                {
                    if (cnts[i] <= cnts[k])
                    {
                        j = k; k = i;
                        continue;
                    }
                    if (cnts[i] <= cnts[j])
                    {
                        j = i;
                        continue;
                    }
                }

                nlen[nn] = (short)(((clen[j] > clen[k]) ? clen[j] : clen[k]) + 1);
                nodes[nn * 2 + 0] = roots[j];
                nodes[nn * 2 + 1] = roots[k];

                roots[nr] = (short)nn;
                cnts[nr] = cnts[j] + cnts[k];
                clen[nr] = nlen[nn];

                //		printf("%d %d %d\n", cnts[j], cnts[k], cnts[nr]);

                nn++; nr++;

                l = 0;
                for (i = 0; i < nr; i++)
                {
                    if ((i == j) || (i == k)) continue;
                    roots[l] = roots[i];
                    cnts[l] = cnts[i];
                    clen[l] = clen[i];
                    l++;
                }
                nr = l;
            }

            l = roots[0];
            j = clen[0];
            k = j;

            i = 4;
            while (((i--)>0) && (k > ml))
                k = PDJHUFF.BalanceTree_r(new ShortPtr(nodes), new ShortPtr(nlen), l, 0, ml);
            if (k > ml) return (-2);	//failed to balance tree

            PDJHUFF.CalcLengths_r(new ShortPtr(nodes), cl, l, 0);
            return (0);
        }

        public static int BuildLengthsAdjust(IntPtr stat, int nc, BytePtr cl, int ml)
        {
            int i, j;

            while (true)
            {
                j = PDJHUFF.BuildLengths(stat, nc, cl, ml);
                if (j < 0)
                {
                    Console.Write("PDJHUFF.BuildLengthsAdjust: Huff Fail %d\n");
                }

                for (i = 0; i < nc; i++)
                    if ((stat[i]!=0) && (cl[i]==0))
                        break;
                if (i >= nc) break;

                Console.Write("PDJHUFF.BuildLengthsAdjust: Fiddle Adjust\n");
                for (i = 0; i < nc; i++)
                    stat[i]++;
                continue;
            }
            return (0);
        }

        public static void EncodeSymbol(PDJPG_Context ctx, int tab, int v)
        {
            tab <<= 8;

            if (ctx.huff_len[tab | v] <= 0)
            {
                Console.Write("EncodeSymbol: Bad {0} {1}\n", tab, v);
            }

            PDJHUFF.WriteNBits(ctx, ctx.huff_code[tab | v], ctx.huff_len[tab | v]);
        }

        public static void EncodeVal(PDJPG_Context ctx, int tab, int z, int v)
        {
            int i, j, k;

            if (v==0) { PDJHUFF.EncodeSymbol(ctx, tab, z << 4); return; }

            if (v > 0)
            {
                i = 1; while (v >= (1 << i)) i++;
                if (i > 15)
                {
                    Console.Write("PDJHUFF.EncodeVal: Overflow A\n");
                    i = 15;
                }

                PDJHUFF.EncodeSymbol(ctx, tab, (z << 4) | i);
                PDJHUFF.WriteNBits(ctx, v, i);
                return;
            }

            i = 1; j = -v; while (j >= (1 << i)) i++;
            if (i > 15)
            {
                Console.Write("PDJHUFF.EncodeVal: Overflow B\n");
                i = 15;
            }

            PDJHUFF.EncodeSymbol(ctx, tab, (z << 4) | i);

            k = (1 << i) - (j + 1);
            PDJHUFF.WriteNBits(ctx, k, i);
            return;
        }

        public static void StatVal(IntPtr stat, int z, int v)
        {
            int i, j;

            if (v==0) { stat[z << 4]++; return; }

            if (v > 0)
            {
                i = 1; while (v >= (1 << i)) i++;
                if (i > 15) i = 15;
                stat[(z << 4) | i]++;
                return;
            }

            i = 1; j = -v; while (j >= (1 << i)) i++;
            if (i > 15) i = 15;
            stat[(z << 4) | i]++;
        }

#if true
        public static int EncodeBlock(PDJPG_Context ctx,
            ShortPtr buf, int dctab, int actab)
        {
            int i, j;

            if (ctx.altvlc)
            {
                i=EncodeBlockAltVLC(ctx, buf, dctab, actab);
                return i;
            }

            PDJHUFF.EncodeVal(ctx, dctab, 0, buf[0]);

            for (i = 1; i < 64; i++)
            {
                if (buf[PDJPG.pdjpg_zigzag2[i]]!=0)
                {
                    PDJHUFF.EncodeVal(ctx, actab, 0, buf[PDJPG.pdjpg_zigzag2[i]]);
                    continue;
                }
                for (j = i; j < 64; j++)
                    if (buf[PDJPG.pdjpg_zigzag2[j]]!=0) break;
                if (j >= 64)
                {
                    PDJHUFF.EncodeSymbol(ctx, actab, 0);
                    break;
                }

                j -= i; if (j > 15) j = 15;
                PDJHUFF.EncodeVal(ctx, actab, j, buf[PDJPG.pdjpg_zigzag2[i + j]]);
                i += j;
            }
            return (0);
        }


        public static int StatBlock(PDJPG_Context ctx, ShortPtr buf, IntPtr dcstat, IntPtr acstat)
        {
            int i, j;

            if (ctx.altvlc)
            {
                i = StatBlockAltVLC(ctx, buf, dcstat, acstat);
                return i;
            }

            PDJHUFF.StatVal(dcstat, 0, buf[0]);
            for (i = 1; i < 64; i++)
            {
                if (buf[PDJPG.pdjpg_zigzag2[i]]!=0)
                {
                    PDJHUFF.StatVal(acstat, 0, buf[PDJPG.pdjpg_zigzag2[i]]);
                    continue;
                }
                for (j = i; j < 64; j++)
                    if (buf[PDJPG.pdjpg_zigzag2[j]]!=0) break;
                if (j >= 64)
                {
                    acstat[0]++;
                    break;
                }

                j -= i; if (j > 15) j = 15;
                PDJHUFF.StatVal(acstat, j, buf[PDJPG.pdjpg_zigzag2[i + j]]);
                i += j;
            }
            return (0);
        }

        public static int DecodeBlock(PDJPG_Context ctx,
            ShortPtr buf, int dctab, int actab,
            int ni, int nn)
        {
            int i, j, k;

            if (ctx.altvlc)
            {
                i = DecodeBlock(ctx, buf, dctab, actab, ni, nn);
                return i;
            }

            for (i = 1; i < 64; i++) buf[i] = 0;
            //(buf+1).memset(0, 63 * sizeof(short));

            buf[0] += PDJHUFF.DecodeDiffDC(ctx, dctab);
            for (i = 1; i < 64; i++)
            {
                j = PDJHUFF.DecodeSymbol(ctx, actab);
                if (j <= 0)
                {
                    if (j < 0)
                    {
                        //PDJPG.printf("bad dct block1 %02X(%d) %d/%d\n", j, j, ni, nn);
                        return (-1);
                    }
                    break;
                }

                i += (j >> 4) & 15;	//preceding 0's
                if ((j & 15) == 0) continue;
                if (i >= 64)
                {
                    //			printf("bad dct block3 %02X(%d) len=%d %d/%d\n",
                    //				j, j, i, ni, nn);
                    break;
                }

                j &= 15;
                k = PDJHUFF.ReadNBits(ctx, j);
                if ((k & (1 << (j - 1))) == 0)
                    k = (-1 << j) + k + 1;

                j = PDJPG.pdjpg_zigzag2[i];
                buf[j] = k;
            }

            if (i > 64)
            {
                //printf("bad dct block2 %02X(%d) len=%d %d/%d\n", j, j, i, ni, nn);
                return (-1);
            }

            return (0);
        }
#endif


#if true
        public static int EncodeBlockAltVLC(PDJPG_Context ctx,
            ShortPtr buf, int dctab, int actab)
        {
            int i, j;

            PDJHUFF.EncodeMegaVal(ctx, dctab, 0, buf[0]);

            for (i = 1; i < 64; i++)
            {
                if (buf[PDJPG.pdjpg_zigzag2[i]] != 0)
                {
                    PDJHUFF.EncodeMegaVal(ctx, actab, 0, buf[PDJPG.pdjpg_zigzag2[i]]);
                    continue;
                }
                for (j = i; j < 64; j++)
                    if (buf[PDJPG.pdjpg_zigzag2[j]] != 0) break;
                if (j >= 64)
                {
                    PDJHUFF.EncodeMegaVal(ctx, actab, 0, 0);
                    break;
                }

                j -= i; if (j > MEGA_MAXRLE) j = MEGA_MAXRLE;
                PDJHUFF.EncodeMegaVal(ctx, actab, j, buf[PDJPG.pdjpg_zigzag2[i + j]]);
                i += j;
            }
            return (0);
        }


        public static int StatBlockAltVLC(PDJPG_Context ctx, ShortPtr buf, IntPtr dcstat, IntPtr acstat)
        {
            int i, j;

            PDJHUFF.StatMegaVal(dcstat, 0, buf[0]);
            for (i = 1; i < 64; i++)
            {
                if (buf[PDJPG.pdjpg_zigzag2[i]] != 0)
                {
                    PDJHUFF.StatMegaVal(acstat, 0, buf[PDJPG.pdjpg_zigzag2[i]]);
                    continue;
                }
                for (j = i; j < 64; j++)
                    if (buf[PDJPG.pdjpg_zigzag2[j]] != 0) break;
                if (j >= 64)
                {
                    PDJHUFF.StatMegaVal(acstat, 0, 0);
                    break;
                }

                j -= i; if (j > MEGA_MAXRLE) j = MEGA_MAXRLE;
                PDJHUFF.StatMegaVal(acstat, j, buf[PDJPG.pdjpg_zigzag2[i + j]]);
                i += j;
            }
            return (0);
        }

        public static int DecodeBlockAltVLC(PDJPG_Context ctx,
            ShortPtr buf, int dctab, int actab,
            int ni, int nn)
        {
            int i, j, k;

            for (i = 1; i < 64; i++) buf[i] = 0;
            //(buf+1).memset(0, 63 * sizeof(short));

            DecodeMegaVal(ctx, dctab, out j, out k);
            buf[0] += k;

            //buf[0] += PDJHUFF.DecodeDiffDC(ctx, dctab);
            for (i = 1; i < 64; i++)
            {
                DecodeMegaVal(ctx, actab, out j, out k);

                if ((j == 0) && (k == 0))
                    break;

                i += j;	//preceding 0's
                if ((i >= 64) || (j < 0))
                {
                    Console.Write("bad dct block3 {0}({1}) len={2} {3}/{4}\n",
                        j, j, i, ni, nn);
                    break;
                }

                j = PDJPG.pdjpg_zigzag2[i];
                buf[j] = k;
            }

#if false
            buf[0] += PDJHUFF.DecodeDiffDC(ctx, dctab);
            for (i = 1; i < 64; i++)
            {
                j = PDJHUFF.DecodeSymbol(ctx, actab);
                if (j <= 0)
                {
                    if (j < 0)
                    {
                        //PDJPG.printf("bad dct block1 %02X(%d) %d/%d\n", j, j, ni, nn);
                        return (-1);
                    }
                    break;
                }

                i += (j >> 4) & 15;	//preceding 0's
                if ((j & 15) == 0) continue;
                if (i >= 64)
                {
                    //			printf("bad dct block3 %02X(%d) len=%d %d/%d\n",
                    //				j, j, i, ni, nn);
                    break;
                }

                j &= 15;
                k = PDJHUFF.ReadNBits(ctx, j);
                if ((k & (1 << (j - 1))) == 0)
                    k = (-1 << j) + k + 1;

                j = PDJPG.pdjpg_zigzag2[i];
                buf[j] = k;
            }
#endif

            if (i > 64)
            {
                //printf("bad dct block2 %02X(%d) len=%d %d/%d\n", j, j, i, ni, nn);
                return (-1);
            }

            return (0);
        }
#endif

#if false
        static ulong[] bsxrp_ibase=new ulong[] {
        	//16 bit range
	        0x0000, 0x0001, 0x0002, 0x0003, 0x0004, 0x0005, 0x0006, 0x0007,
	        0x0008, 0x000A, 0x000C, 0x000E,
	
	        0x0010, 0x0014, 0x0018, 0x001C, 0x0020, 0x0028, 0x0030, 0x0038,
	        0x0040, 0x0050, 0x0060, 0x0070, 0x0080, 0x00A0, 0x00C0, 0x00E0,
	        0x0100, 0x0140, 0x0180, 0x01C0, 0x0200, 0x0280, 0x0300, 0x0380,
	        0x0400, 0x0500, 0x0600, 0x0700, 0x0800, 0x0A00, 0x0C00, 0x0E00,
	        0x1000, 0x1400, 0x1800, 0x1C00, 0x2000, 0x2800, 0x3000, 0x3800,
	        0x4000, 0x5000, 0x6000, 0x7000, 0x8000, 0xA000, 0xC000, 0xE000,
	
	        //32-bit range
	        0x00010000, 0x00014000, 0x00018000, 0x0001C000,
	        0x00020000, 0x00028000, 0x00030000, 0x00038000,
	        0x00040000, 0x00050000, 0x00060000, 0x00070000,
	        0x00080000, 0x000A0000, 0x000C0000, 0x000E0000,

	        0x00100000, 0x00140000, 0x00180000, 0x001C0000,
	        0x00200000, 0x00280000, 0x00300000, 0x00380000,
	        0x00400000, 0x00500000, 0x00600000, 0x00700000,
	        0x00800000, 0x00A00000, 0x00C00000, 0x00E00000,

	        0x01000000, 0x01400000, 0x01800000, 0x01C00000,
	        0x02000000, 0x02800000, 0x03000000, 0x03800000,
	        0x04000000, 0x05000000, 0x06000000, 0x07000000,
	        0x08000000, 0x0A000000, 0x0C000000, 0x0E000000,

	        0x10000000, 0x14000000, 0x18000000, 0x1C000000,
	        0x20000000, 0x28000000, 0x30000000, 0x38000000,
	        0x40000000, 0x50000000, 0x60000000, 0x70000000,
	        0x80000000, 0xA0000000, 0xC0000000, 0xE0000000,

	        //64 bit range
	        0x0000000100000000, 0x0000000140000000,
	        0x0000000180000000, 0x00000001C0000000,
	        0x0000000200000000, 0x0000000280000000,
	        0x0000000300000000, 0x0000000380000000,
	        0x0000000400000000, 0x0000000500000000,
	        0x0000000600000000, 0x0000000700000000,
	        0x0000000800000000, 0x0000000A00000000,
	        0x0000000C00000000, 0x0000000E00000000,

        	0x0000001000000000, 0x0000001400000000,
	        0x0000001800000000, 0x0000001C00000000,
	        0x0000002000000000, 0x0000002800000000,
	        0x0000003000000000, 0x0000003800000000,
	        0x0000004000000000, 0x0000005000000000,
	        0x0000006000000000, 0x0000007000000000,
	        0x0000008000000000, 0x000000A000000000,
	        0x000000C000000000, 0x000000E000000000,

	        0x0000010000000000, 0x0000014000000000,
	        0x0000018000000000, 0x000001C000000000,
	        0x0000020000000000, 0x0000028000000000,
	        0x0000030000000000, 0x0000038000000000,
	        0x0000040000000000, 0x0000050000000000,
	        0x0000060000000000, 0x0000070000000000,
	        0x0000080000000000, 0x00000A0000000000,
	        0x00000C0000000000, 0x00000E0000000000,

	        0x0000100000000000, 0x0000140000000000,
	        0x0000180000000000, 0x00001C0000000000,
	        0x0000200000000000, 0x0000280000000000,
	        0x0000300000000000, 0x0000380000000000,
	        0x0000400000000000, 0x0000500000000000,
	        0x0000600000000000, 0x0000700000000000,
	        0x0000800000000000, 0x0000A00000000000,
	        0x0000C00000000000, 0x0000E00000000000,

	        0x0001000000000000, 0x0001400000000000,
	        0x0001800000000000, 0x0001C00000000000,
	        0x0002000000000000, 0x0002800000000000,
	        0x0003000000000000, 0x0003800000000000,
	        0x0004000000000000, 0x0005000000000000,
	        0x0006000000000000, 0x0007000000000000,
	        0x0008000000000000, 0x000A000000000000,
	        0x000C000000000000, 0x000E000000000000,

	        0x0010000000000000, 0x0014000000000000,
	        0x0018000000000000, 0x001C000000000000,
	        0x0020000000000000, 0x0028000000000000,
	        0x0030000000000000, 0x0038000000000000,
	        0x0040000000000000, 0x0050000000000000,
	        0x0060000000000000, 0x0070000000000000,
	        0x0080000000000000, 0x00A0000000000000,
	        0x00C0000000000000, 0x00E0000000000000,

	        0x0100000000000000, 0x0140000000000000,
	        0x0180000000000000, 0x01C0000000000000,
	        0x0200000000000000, 0x0280000000000000,
	        0x0300000000000000, 0x0380000000000000,
	        0x0400000000000000, 0x0500000000000000,
	        0x0600000000000000, 0x0700000000000000,
	        0x0800000000000000, 0x0A00000000000000,
	        0x0C00000000000000, 0x0E00000000000000,

	        0x1000000000000000, 0x1400000000000000,
	        0x1800000000000000, 0x1C00000000000000,
	        0x2000000000000000, 0x2800000000000000,
	        0x3000000000000000, 0x3800000000000000,
	        0x4000000000000000, 0x5000000000000000,
	        0x6000000000000000, 0x7000000000000000,
	        0x8000000000000000, 0xA000000000000000,
	        0xC000000000000000, 0xE000000000000000,
    	};

        static int[] bsxrp_iextra = new int[] {
    		 0,  0,  0,  0,   0,  0,  0,  0,
		    1,  1,  1,  1,
		    2,  2,  2,  2,   3,  3,  3,  3,
		    4,  4,  4,  4,   5,  5,  5,  5,
		    6,  6,  6,  6,   7,  7,  7,  7,
		    8,  8,  8,  8,   9,  9,  9,  9,
		    10, 10, 10, 10,  11, 11, 11, 11,
		    12, 12, 12, 12,  13, 13, 13, 13,
		
		    //32 bit range
		    14, 14, 14, 14,  15, 15, 15, 15,
		    16, 16, 16, 16,  17, 17, 17, 17,
   
    		18, 18, 18, 18,  19, 19, 19, 19,
		    20, 20, 20, 20,  21, 21, 21, 21,

		    22, 22, 22, 22,  23, 23, 23, 23,
		    24, 24, 24, 24,  25, 25, 25, 25,

		    26, 26, 26, 26,  27, 27, 27, 27,
		    28, 28, 28, 28,  29, 29, 29, 29,
		
    		//64 bit range
		    30, 30, 30, 30,  31, 31, 31, 31,
		    32, 32, 32, 32,  33, 33, 33, 33,

		    34, 34, 34, 34,  35, 35, 35, 35,
		    36, 36, 36, 36,  37, 37, 37, 37,

    		38, 38, 38, 38,  39, 39, 39, 39,
	    	40, 40, 40, 40,  41, 41, 41, 41,

    		42, 42, 42, 42,  43, 43, 43, 43,
	    	44, 44, 44, 44,  45, 45, 45, 45,

    		46, 46, 46, 46,  47, 47, 47, 47,
	    	48, 48, 48, 48,  49, 49, 49, 49,

    		50, 50, 50, 50,  51, 51, 51, 51,
	    	52, 52, 52, 52,  53, 53, 53, 53,

    		54, 54, 54, 54,  55, 55, 55, 55,
	    	56, 56, 56, 56,  57, 57, 57, 57,

    		58, 58, 58, 58,  59, 59, 59, 59,
	    	60, 60, 60, 60,  61, 61, 61, 61,
	    };
#endif

#if true
        static ulong[] bsxrp_ibase=new ulong[] {
        	//16 bit range
	        0x0000, 0x0001, 0x0002, 0x0003,
            0x0004, 0x0006, 0x0008, 0x000C,
	        0x0010, 0x0018, 0x0020, 0x0030,
            0x0040, 0x0060, 0x0080, 0x00C0,
            0x0100, 0x0180, 0x0200, 0x0300,
            0x0400, 0x0600, 0x0800, 0x0C00,
            0x1000, 0x1800, 0x2000, 0x3000,
            0x4000, 0x6000, 0x8000, 0xC000,

            //32-bit range
            0x00010000, 0x00018000, 0x00020000, 0x00030000,
            0x00040000, 0x00060000, 0x00080000, 0x000C0000,
            0x00100000, 0x00180000, 0x00200000, 0x00300000,
            0x00400000, 0x00600000, 0x00800000, 0x00C00000,
            0x01000000, 0x01800000, 0x02000000, 0x03000000,
            0x04000000, 0x06000000, 0x08000000, 0x0C000000,
            0x10000000, 0x18000000, 0x20000000, 0x30000000,
            0x40000000, 0x60000000, 0x80000000, 0xC0000000,

            //64-bit range
            0x0000000100000000, 0x0000000180000000, 0x0000000200000000, 0x0000000300000000,
            0x0000000400000000, 0x0000000600000000, 0x0000000800000000, 0x0000000C00000000,
            0x0000001000000000, 0x0000001800000000, 0x0000002000000000, 0x0000003000000000,
            0x0000004000000000, 0x0000006000000000, 0x0000008000000000, 0x000000C000000000,
            0x0000010000000000, 0x0000018000000000, 0x0000020000000000, 0x0000030000000000,
            0x0000040000000000, 0x0000060000000000, 0x0000080000000000, 0x00000C0000000000,
            0x0000100000000000, 0x0000180000000000, 0x0000200000000000, 0x0000300000000000,
            0x0000400000000000, 0x0000600000000000, 0x0000800000000000, 0x0000C00000000000,
            0x0001000000000000, 0x0001800000000000, 0x0002000000000000, 0x0003000000000000,
            0x0004000000000000, 0x0006000000000000, 0x0008000000000000, 0x000C000000000000,
            0x0010000000000000, 0x0018000000000000, 0x0020000000000000, 0x0030000000000000,
            0x0040000000000000, 0x0060000000000000, 0x0080000000000000, 0x00C0000000000000,
            0x0100000000000000, 0x0180000000000000, 0x0200000000000000, 0x0300000000000000,
            0x0400000000000000, 0x0600000000000000, 0x0800000000000000, 0x0C00000000000000,
            0x1000000000000000, 0x1800000000000000, 0x2000000000000000, 0x3000000000000000,
            0x4000000000000000, 0x6000000000000000, 0x8000000000000000, 0xC000000000000000,

    	};

        static int[] bsxrp_iextra = new int[] {
    		 0,  0,  0,  0,
		     1,  1,  2,  2,
		     3,  3,  4,  4,
		     5,  5,  6,  6,
		     7,  7,  8,  8,
		     9,  9, 10, 10,
		    11, 11, 12, 12,
		    13, 13, 14, 14,
		
		    //32 bit range
		    15, 15, 16, 16,
		    17, 17, 18, 18,
    		19, 19, 20, 20,
		    21, 21, 22, 22,
		    23, 23, 24, 24,
		    25, 25, 26, 26,
		    27, 27, 28, 28,
		    29, 29, 30, 30,
		
    		//64 bit range
		    31, 31, 32, 32,
            
            33, 33, 34, 34,
            35, 35, 36, 36,
            37, 37, 38, 38,
            39, 39, 40, 40,
            41, 41, 42, 42,
            43, 43, 44, 44,
            45, 45, 46, 46,
            47, 47, 48, 48,
            49, 49, 50, 50,
            51, 51, 52, 52,
            53, 53, 54, 54,
            55, 55, 56, 56,
            57, 57, 58, 58,
            59, 59, 60, 60,
            61, 61, 62, 62,
	    };
#endif

        public static void EncodeUVLC(PDJPG_Context ctx, int tab, int sbase, ulong val)
        {
            ulong lj, lk;
            int i;

            lj = val;
            for (i = 0; i < 252; i++)
            {
                lk = bsxrp_ibase[i] + (1UL << bsxrp_iextra[i]);
                if ((val >= bsxrp_ibase[i]) && (lj < lk))
                {
                    EncodeSymbol(ctx, tab, sbase + i);
                    WriteNBitsL(ctx, lj - bsxrp_ibase[i], bsxrp_iextra[i]);
                    break;
                }
            }
        }

        public static void StatUVLC(IntPtr stat, int sbase, ulong val)
        {
            ulong lj, lk;
            int i;

            lj = val;
            for (i = 0; i < 252; i++)
            {
                lk = bsxrp_ibase[i] + (1UL << bsxrp_iextra[i]);
                if ((val >= bsxrp_ibase[i]) && (lj < lk))
                {
                    stat[sbase + i]++;
                    break;
                }
            }
        }

        public static ulong DecodeUVLC(PDJPG_Context ctx, int tab)
        {
            ulong lk;
            int i;

            i = DecodeSymbol(ctx, tab);
            lk = bsxrp_ibase[i] + ReadNBitsL(ctx, bsxrp_iextra[i]);
            return (lk);
        }

        public static void DecodePrefixUVLC(PDJPG_Context ctx, int pf, out ulong v)
        {
            v = bsxrp_ibase[pf] + ReadNBitsL(ctx, bsxrp_iextra[pf]);
        }

#if true

#if false
        public static void EncodeMegaUVLC(PDJPG_Context ctx, int tab, int b, int v)
        {
            int i, j, k;

            if (v > 0)
            {
                i = 1; while (v >= (1 << i)) i++;
                if (i > 63)
                {
                    Console.Write("PDJHUFF.EncodeVal: Overflow A\n");
                    i = 63;
                }

                PDJHUFF.EncodeSymbol(ctx, tab, b + i);
                PDJHUFF.WriteNBits(ctx, v, i);
                return;
            }

            if (v == 0)
            {
                PDJHUFF.EncodeSymbol(ctx, tab, b);
            }

            i = 1; j = -v; while (j >= (1 << i)) i++;
            if (i > 63)
            {
                Console.Write("PDJHUFF.EncodeVal: Overflow B\n");
                i = 63;
            }

            PDJHUFF.EncodeSymbol(ctx, tab, b + i);

            k = (1 << i) - (j + 1);
            PDJHUFF.WriteNBits(ctx, k, i);
            return;
        }


        public static void StatMegaUVLC(IntPtr stat, int b, int v)
        {
            int i, j;

            if (v > 0)
            {
                i = 1; while (v >= (1 << i)) i++;
                if (i > 63) i = 63;
                stat[b + i]++;
                return;
            }

            if (v == 0)
            {
                stat[b]++;
                return;
            }

            i = 1; j = -v; while (j >= (1 << i)) i++;
            if (i > 15) i = 15;
            stat[b + i]++;
        }

        public static void DecodeMegaUVLC(PDJPG_Context ctx, int pf, out int v)
        {
            int k;

            if (pf == 0)
            {
                v = 0;
                return;
            }

            k = PDJHUFF.ReadNBits(ctx, pf);
            if ((k & (1 << (pf - 1))) == 0)
                k = (-1 << pf) + k + 1;
            v = k;
        }
#endif

        public static void EncodeMegaVLC(PDJPG_Context ctx, int tab, int b, int v)
        {
            ulong lv;
            lv = (ulong)((v >= 0) ? (v << 1) : (((-v) << 1) - 1));
            //EncodeMegaUVLC(ctx, tab, b, i);
            EncodeUVLC(ctx, tab, b, lv);
        }

        public static void StatMegaVLC(IntPtr stat, int b, int v)
        {
            ulong lv;
            lv = (ulong)((v >= 0) ? (v << 1) : (((-v) << 1) - 1));
            //StatMegaUVLC(stat, b, i);
            StatUVLC(stat, b, lv);
        }

        public static void DecodeMegaVLC(PDJPG_Context ctx, int pf, out int v)
        {
            ulong lv;
            long li;
            DecodePrefixUVLC(ctx, pf, out lv);
            li = ((lv & 1) != 0) ? (-(long)((lv + 1) >> 1)) : (long)(lv >> 1);
            v = (int)li;
        }

        public static void EncodeMegaVal(PDJPG_Context ctx, int tab, int z, int v)
        {
            int i, j, k;

#if true
            if ((z < 14) && (v < 32767) && (v > -32767))
            {
                EncodeVal(ctx, tab, z, v);
                return;
            }
            else
            {
                //EncodeMegaVLC(ctx, tab, 224, z);
                EncodeUVLC(ctx, tab, 224, (ulong)z);
                EncodeMegaVLC(ctx, tab, 192, v);
                return;
            }
#endif

#if false
            EncodeVal(ctx, tab, z, v);
            return;
#endif

#if false
            if ((z == 0) && (v == 0))
            {
                PDJHUFF.EncodeSymbol(ctx, tab, 128);
                return;
            }

            if (z > 0)
            {
                EncodeMegaVLC(ctx, tab, 128, z);
            }
            EncodeMegaVLC(ctx, tab, 0, v);

            //if (v == 0) { PDJHUFF.EncodeSymbol(ctx, tab, z << 4); return; }
#endif

        }

        public static void StatMegaVal(IntPtr stat, int z, int v)
        {
            int i, j;

#if true
            if ((z < 14) && (v < 32767) && (v > -32767))
            {
                StatVal(stat, z, v);
                return;
            }
            else
            {
                //StatMegaVLC(stat, 224, z);
                StatUVLC(stat, 224, (ulong)z);
                StatMegaVLC(stat, 192, v);
                return;
            }
#endif

#if false
            StatVal(stat, z, v);
            return;
#endif

#if false
            if ((z == 0) && (v == 0))
            {
                stat[128]++;
                return;
            }

            //if (v == 0) { stat[z << 4]++; return; }
            if (z > 0)
            {
                StatMegaVLC(stat, 128, z);
            }
            StatMegaVLC(stat, 0, v);
#endif
        }


        public static int DecodeMegaVal(PDJPG_Context ctx, int tab, out int z, out int v)
        {
            ulong lv;
            int i, j, k;
#if true
            j = PDJHUFF.DecodeSymbol(ctx, tab);
            if (j < 224)
            {
                if (j <= 0)
                {
                    if (j < 0)
                    {
                        //PDJPG.printf("bad dct block1 %02X(%d) %d/%d\n", j, j, ni, nn);
                        z = 0; v = 0;
                        return -1;
                    }
                    z = 0; v = 0;
                    return 0;
                }

                z = (j >> 4) & 15;	//preceding 0's

                j &= 15;
                k = PDJHUFF.ReadNBits(ctx, j);
                if ((k & (1 << (j - 1))) == 0)
                    k = (-1 << j) + k + 1;

                v = k;

                return 0;
            }
            else
            {
                //DecodeMegaVLC(ctx, j - 224, out k);
                DecodePrefixUVLC(ctx, j - 224, out lv);
                //z = k;
                z = (int)lv;

                j = PDJHUFF.DecodeSymbol(ctx, tab);

                DecodeMegaVLC(ctx, j - 192, out k);
                v = k;
                return 0;
            }
#endif

#if false
            j = PDJHUFF.DecodeSymbol(ctx, tab);
            if (j <= 0)
            {
                if (j < 0)
                {
                    //PDJPG.printf("bad dct block1 %02X(%d) %d/%d\n", j, j, ni, nn);
                    z = 0; v = 0;
                    return -1;
                }
                z = 0; v = 0;
                return 0;
            }

            z = (j >> 4) & 15;	//preceding 0's

            j &= 15;
            k = PDJHUFF.ReadNBits(ctx, j);
            if ((k & (1 << (j - 1))) == 0)
                k = (-1 << j) + k + 1;

            v = k;

            return 0;
#endif

#if false
            j = PDJHUFF.DecodeSymbol(ctx, tab);
            if (j < 0)
            {
                //PDJPG.printf("bad dct block1 %02X(%d) %d/%d\n", j, j, ni, nn);
                z = 0; v = 0;
                return (-1);
            }

            if (j >= 128)
            {
                if (j == 128)
                {
                    z = 0; v = 0;
                    return 0;
                }

                DecodeMegaVLC(ctx, j - 128, out k);
                z = k;

                j = PDJHUFF.DecodeSymbol(ctx, tab);
            }
            else
            {
                z = 0;
            }

            DecodeMegaVLC(ctx, j, out k);
            v = k;
            return 0;
#endif
        }

        //static int MEGA_MAXRLE = 15;
        static int MEGA_MAXRLE = 255;

        public static int EncodeMegaBlock(PDJPG_Context ctx,
            ShortPtr buf, int dctab, int actab)
        {
            int i, j, k;

            PDJHUFF.EncodeMegaVal(ctx, dctab, 0, buf[0]);

            for (i = 1; i < 64; i++)
            {
                k = buf[PDJPG.pdjpg_doublezigzag2[i]];
                if (k != 0)
                {
                    PDJHUFF.EncodeMegaVal(ctx, dctab, 0, k);
                    continue;
                }
                for (j = i; j < 64; j++)
                    if (buf[PDJPG.pdjpg_doublezigzag2[j]] != 0) break;

                if (j >= 64)
                {
                    //PDJHUFF.EncodeSymbol(ctx, dctab, 0);
                    PDJHUFF.EncodeMegaVal(ctx, dctab, 0, 0);
                    break;
                }

                j -= i; if (j > MEGA_MAXRLE) j = MEGA_MAXRLE;
                PDJHUFF.EncodeMegaVal(ctx, dctab, j, buf[PDJPG.pdjpg_doublezigzag2[i + j]]);
                i += j;
            }

            for (i = 64; i < 4096; i++)
            {
                k = buf[PDJPG.pdjpg_doublezigzag2[i]];
                if (k != 0)
                {
                    PDJHUFF.EncodeMegaVal(ctx, actab, 0, k);
                    continue;
                }

                k = i + (MEGA_MAXRLE + 1); if (k > 4096) k = 4096;
                for (j = i; j < k; j++)
                    if (buf[PDJPG.pdjpg_doublezigzag2[j]] != 0) break;

                if (j >= 4096)
                {
                    //PDJHUFF.EncodeSymbol(ctx, actab, 0);
                    PDJHUFF.EncodeMegaVal(ctx, actab, 0, 0);
                    break;
                }

                j -= i; if (j > MEGA_MAXRLE) j = MEGA_MAXRLE;
                PDJHUFF.EncodeMegaVal(ctx, actab, j, buf[PDJPG.pdjpg_doublezigzag2[i + j]]);
                i += j;
            }

//            PDJHUFF.EncodeSymbol(ctx, actab, 0);

            return (0);
        }

        public static int StatMegaBlock(ShortPtr buf, IntPtr dcstat, IntPtr acstat)
        {
            int i, j, k;

            PDJHUFF.StatMegaVal(dcstat, 0, buf[0]);

            for (i = 1; i < 64; i++)
            {
                k = buf[PDJPG.pdjpg_doublezigzag2[i]];
                if (k != 0)
                {
                    PDJHUFF.StatMegaVal(dcstat, 0, k);
                    continue;
                }
                for (j = i; j < 64; j++)
                    if (buf[PDJPG.pdjpg_doublezigzag2[j]] != 0) break;
                if (j >= 64)
                {
                    //dcstat[0]++;
                    PDJHUFF.StatMegaVal(dcstat, 0, 0);
                    break;
                }

                j -= i; if (j > MEGA_MAXRLE) j = MEGA_MAXRLE;
                PDJHUFF.StatMegaVal(dcstat, j, buf[PDJPG.pdjpg_doublezigzag2[i + j]]);
                i += j;
            }

            for (i = 64; i < 4096; i++)
            {
                k = buf[PDJPG.pdjpg_doublezigzag2[i]];
                if (k != 0)
                {
                    PDJHUFF.StatMegaVal(acstat, 0, k);
                    continue;
                }

                k = i + (MEGA_MAXRLE + 1); if (k > 4096) k = 4096;
                for (j = i; j < k; j++)
                    if (buf[PDJPG.pdjpg_doublezigzag2[j]] != 0) break;
                if (j >= 4096)
                {
                    //acstat[0]++;
                    PDJHUFF.StatMegaVal(acstat, 0, 0);
                    break;
                }

                j -= i; if (j > MEGA_MAXRLE) j = MEGA_MAXRLE;
                PDJHUFF.StatMegaVal(acstat, j, buf[PDJPG.pdjpg_doublezigzag2[i + j]]);
                i += j;
            }

//            acstat[0]++;

            return (0);
        }
#endif

#if true
        public static int DecodeMegaBlock(PDJPG_Context ctx,
            ShortPtr buf, int dctab, int actab,
            int ni, int nn)
        {
            int i, j, k;

            for (i = 1; i < 4096; i++) buf[i] = 0;
            //(buf+1).memset(0, 63 * sizeof(short));
            j = 0;

            DecodeMegaVal(ctx, dctab, out j, out k);
            buf[0] += k;

            //buf[0] += PDJHUFF.DecodeDiffDC(ctx, dctab);
            for (i = 1; i < 64; i++)
            {
                DecodeMegaVal(ctx, dctab, out j, out k);

                if ((j == 0) && (k == 0))
                    break;

                i += j;	//preceding 0's
                if ((i >= 64) || (j<0))
                {
                    Console.Write("bad dct block3 {0}({1}) len={2} {3}/{4}\n",
                    	j, j, i, ni, nn);
                    break;
                }

                j = PDJPG.pdjpg_doublezigzag2[i];
                buf[j] = k;
            }

            for (i = 64; i < 4096; i++)
            {
                DecodeMegaVal(ctx, actab, out j, out k);

                if ((j == 0) && (k == 0))
                    break;

                i += j;	//preceding 0's
                if ((i >= 4096) || (j<0))
                {
                    Console.Write("bad dct block3 {0}({1}) len={2} {3}/{4}\n",
                        j, j, i, ni, nn);
                    break;
                }

                j = PDJPG.pdjpg_doublezigzag2[i];
                buf[j] = k;
            }

#if true
            if (i > 4096)
            {
                Console.Write("bad dct block2 {0}({1}) len={2} {3}/{4}\n", j, j, i, ni, nn);
                return (-1);
            }
#endif

            return (0);
        }
#endif
    }
}
