﻿using System;
using System.Collections.Generic;
using System.Text;
using PaintDotNet;
using PaintDotNet.Data;
using System.IO;
using System.Drawing;
using System.Windows;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace BGBTechBTJ
{
    public class MyFileType : FileType
    {
        public MyFileType()
            : base("BGBTech JPEG Test",
                FileTypeFlags.SupportsLoading | FileTypeFlags.SupportsSaving | FileTypeFlags.SupportsLayers,
                new String[] { ".btj", ".jpg" })
        {
        }

        protected Bitmap BitmapFromByteBuffer(byte[] img, int xs, int ys)
        {
            Bitmap bmp;
            int cr, cg, cb, ca;
            int i, j, n;
            bmp = new Bitmap(xs, ys);
            n = xs * ys;
            for (i = 0; i < ys; i++)
                for (j = 0; j < xs; j++)
                {
                    cr = img[(i * xs + j) * 4 + 0];
                    cg = img[(i * xs + j) * 4 + 1];
                    cb = img[(i * xs + j) * 4 + 2];
                    ca = img[(i * xs + j) * 4 + 3];
                    //                        ca = 128;
                    bmp.SetPixel(j, ys - i - 1, Color.FromArgb(ca, cr, cg, cb));
                }
            return bmp;
        }

        protected Bitmap BitmapFromByteBufferRGB(byte[] img, int xs, int ys)
        {
            Bitmap bmp;
            int cr, cg, cb, ca;
            int i, j, n;
            bmp = new Bitmap(xs, ys);
            n = xs * ys;
            for (i = 0; i < ys; i++)
                for (j = 0; j < xs; j++)
                {
                    cr = img[(i * xs + j) * 4 + 0];
                    cg = img[(i * xs + j) * 4 + 1];
                    cb = img[(i * xs + j) * 4 + 2];
                    //ca = img[(i * xs + j) * 4 + 3];
                    ca = 255;
                    bmp.SetPixel(j, ys - i - 1, Color.FromArgb(ca, cr, cg, cb));
                }
            return bmp;
        }

        protected Bitmap BitmapFromByteBufferYI(byte[] img, int xs, int ys, int yi)
        {
            Bitmap bmp;
//            int cr, cg, cb, ca;
            int i, j, k, n;
            bmp = new Bitmap(xs, ys);
            n = xs * ys;
            for (i = 0; i < ys; i++)
                for (j = 0; j < xs; j++)
                {
                    k = img[(i * xs + j) * 4 + yi];
                    bmp.SetPixel(j, ys - i - 1, Color.FromArgb(255, k, k, k));
                }
            return bmp;
        }

        protected void LoadDocumentLayer(Document doc, BytePtr ibuf, int sz, string name)
        {
            BitmapLayer layer;
            Bitmap bmp;
            byte[] rgba;
            byte[] norm;
            byte[] spec;
            byte[] luma;
            int xs, ys, ln, fl;
//            int i, j;

            rgba = new byte[4096 * 4096 * 4];
            norm = new byte[4096 * 4096 * 4];
            spec = new byte[4096 * 4096 * 4];
            luma = new byte[4096 * 4096 * 4];
            PDJPG.PDJPG_DecodeComponent(ibuf, sz, rgba, norm, spec, luma, out xs, out ys, out fl);

            //PDJPG_DecodeHasComponent()

            ln = doc.Layers.Count;
            //doc.Layers.Insert(ln, null);

            if (true)
            {
                layer = new BitmapLayer(xs, ys);
                layer.Name = name;
                layer.Opacity = 255;
                layer.Visible = true;

                if((fl&PDJPG.PDJPG_BCSFL_LAYER_HIDDEN)!=0)
                    layer.Visible = false;

                bmp = BitmapFromByteBuffer(rgba, xs, ys);
                layer.Surface.CopyFromGdipBitmap(bmp, false);
                doc.Layers.Insert(ln++, layer);
            }

            if (PDJPG.PDJPG_DecodeHasComponent(ibuf, sz, "XYZ"))
            {
                layer = new BitmapLayer(xs, ys);
                layer.Name = name + "::Normal";
                layer.Opacity = 255;
                layer.Visible = false;

                bmp = BitmapFromByteBufferRGB(norm, xs, ys);
                layer.Surface.CopyFromGdipBitmap(bmp, false);
                doc.Layers.Insert(ln++, layer);
            }

            if (PDJPG.PDJPG_DecodeHasComponent(ibuf, sz, "SpRGB"))
            {
                layer = new BitmapLayer(xs, ys);
                layer.Name = name + "::Specular";
                layer.Opacity = 255;
                layer.Visible = false;

                bmp = BitmapFromByteBufferRGB(spec, xs, ys);
                layer.Surface.CopyFromGdipBitmap(bmp, false);
                doc.Layers.Insert(ln++, layer);
            }

            if (PDJPG.PDJPG_DecodeHasComponent(ibuf, sz, "LuRGB"))
            {
                layer = new BitmapLayer(xs, ys);
                layer.Name = name + "::Luma";
                layer.Opacity = 255;
                layer.Visible = false;

                bmp = BitmapFromByteBufferRGB(luma, xs, ys);
                layer.Surface.CopyFromGdipBitmap(bmp, false);
                doc.Layers.Insert(ln++, layer);
            }

        }

        protected override Document OnLoad(Stream input)
        {
            try
            {

#if true
                //                Bitmap b = new Bitmap(500, 500);
//                b.
                Bitmap b;
//                BytePtr bptbuf;
                byte[] temp;
//                BytePtr img;
                BytePtr cs;
//                byte[] img;
                string cln;
                int i, j, n, sz, sz1, xs, ys;
                int cr, cg, cb, ca;

                temp = new byte[4096 * 4096 * 4];

                n = 4096 * 4096;
                for (i = 0; i < n; i++)
                {
                    j = input.ReadByte();
                    if (j < 0) break;
                    temp[i] = (byte)j;
                }
                sz = i;

#if true
                Document doc;
                PDJPG.PDJPG_DummyDecode(new BytePtr(temp), sz, out xs, out ys);
                doc = new Document(xs, ys);
//                LoadDocumentLayer(doc, new BytePtr(temp), sz, "Background");

                cs = PDJPG.PDJPG_DecodeScanNextTagLayer(new BytePtr(temp), sz, out cln);
                if (cs.isNull)
                {
                    LoadDocumentLayer(doc, new BytePtr(temp), sz, "Background");
                }
                else
                {
                    while (!cs.isNull)
                    {
                        sz1 = sz - cs.pos;
                        LoadDocumentLayer(doc, cs, sz1, cln);
                        cs = PDJPG.PDJPG_DecodeScanNextTagLayer(cs, sz1, out cln);
                    }
                }

                return doc;
#endif

#if false
                //                i = c.DecodeImage(temp, sz, ref xs, ref ys);
//                bptbuf = PDJPG.PDJPG_Decode(new BytePtr(temp), sz, out xs, out ys);
//                img = (BytePtr)bptbuf;

                img = new byte[4096 * 4096 * 4];
                PDJPG.PDJPG_DecodeComponent(new BytePtr(temp), sz, img, null, null, null, out xs, out ys);

                b = new Bitmap(xs, ys);
                n = xs * ys;
                for (i = 0; i < ys; i++)
                    for (j = 0; j < xs; j++)
                    {
                        cr = img[(i * xs + j) * 4 + 0];
                        cg = img[(i * xs + j) * 4 + 1];
                        cb = img[(i * xs + j) * 4 + 2];
                        ca = img[(i * xs + j) * 4 + 3];
//                        ca = 128;
                        b.SetPixel(j, i, Color.FromArgb(ca, cr, cg, cb));
                    }

                return Document.FromImage(b);
//                return Document.FromImage(b);
#endif
#endif
            }
            catch
            {
                MessageBox.Show("Problem Importing File");

                Bitmap b = new Bitmap(500, 500);
                return Document.FromImage(b);
            }
        }

        protected void BitmapToByteBuffer(Bitmap bmp, out byte[] img, out int xs, out int ys)
        {
            Color clr;
            int i, j;

            xs = bmp.Width;
            ys = bmp.Height;
            img = new byte[xs * ys * 4];

            for (i = 0; i < ys; i++)
                for (j = 0; j < xs; j++)
                {
                    clr = bmp.GetPixel(j, ys - i - 1);
                    img[(i * xs + j) * 4 + 0] = clr.R;
                    img[(i * xs + j) * 4 + 1] = clr.G;
                    img[(i * xs + j) * 4 + 2] = clr.B;
                    img[(i * xs + j) * 4 + 3] = clr.A;
                }
        }

        protected BitmapLayer FetchDocumentLayer(Document input, string name)
        {
            BitmapLayer layer;
            int i;

            for (i = 0; i < input.Layers.Count; i++)
            {
                layer = (BitmapLayer)input.Layers[i];
                if (layer.Name == name)
                    return layer;
            }
            return null;
        }

        protected bool FetchDocumentLayerAsByteBuffer(Document input, string name,
            out byte[] img, out int xs, out int ys)
        {
            Bitmap bmp;
            BitmapLayer layer;
            //byte[] img;
            //int i, j;

            layer = FetchDocumentLayer(input, name);
            if (layer == null)
            {
                img = null; xs = 0; ys = 0;
                return false;
            }

            bmp = layer.Surface.CreateAliasedBitmap();
            BitmapToByteBuffer(bmp, out img, out xs, out ys);
            return true;
        }

        protected bool FetchDocumentLayerAsByteBuffer(Document input, string name, int layernum,
            out byte[] img, out int xs, out int ys)
        {
            Bitmap bmp;
            BitmapLayer layer;
            //byte[] img;
            //int i, j;

            //layer = FetchDocumentLayer(input, name);
            layer = (BitmapLayer)input.Layers[layernum];

            if (layer == null)
            {
                img = null; xs = 0; ys = 0;
                return false;
            }

            bmp = layer.Surface.CreateAliasedBitmap();
            BitmapToByteBuffer(bmp, out img, out xs, out ys);
            return true;
        }

        protected BytePtr EmitDocumentTagLayer(Document input, PDJPG_Context ctx, BytePtr ct, string name, int layernum, int qf)
        {
            Bitmap bmp;
            BitmapLayer layer;
            int xs, ys, xs1, ys1, sz;
            byte[] rgba, norm, spec, luma;
            int i, j;

            FetchDocumentLayerAsByteBuffer(input, name, layernum, out rgba, out xs, out ys);
            FetchDocumentLayerAsByteBuffer(input, name + "::Normal", out norm, out xs1, out ys1);
            FetchDocumentLayerAsByteBuffer(input, name + "::Specular", out spec, out xs1, out ys1);
            FetchDocumentLayerAsByteBuffer(input, name + "::Luma", out luma, out xs1, out ys1);

            //bmp = layer.Surface.CreateAliasedBitmap();
            //BitmapToByteBuffer(bmp, out img, out xs, out ys);

            i = PDJPG.PDJPG_EncodeComponentCtxI2(ctx, rgba, norm, spec, luma, null, ct, xs, ys, qf, name);
            ct += i;
            return ct;
        }

        protected BytePtr EmitDocumentBaseLayer(Document input, PDJPG_Context ctx, BytePtr ct, string name, int qf)
        {
            Bitmap bmp;
            BitmapLayer layer;
            int xs, ys, xs1, ys1, sz;
            byte[] rgba, norm, spec, luma;
            int i, j;

            FetchDocumentLayerAsByteBuffer(input, name, out rgba, out xs, out ys);
            FetchDocumentLayerAsByteBuffer(input, name + "::Normal", out norm, out xs1, out ys1);
            FetchDocumentLayerAsByteBuffer(input, name + "::Specular", out spec, out xs1, out ys1);
            FetchDocumentLayerAsByteBuffer(input, name + "::Luma", out luma, out xs1, out ys1);

            //bmp = layer.Surface.CreateAliasedBitmap();
            //BitmapToByteBuffer(bmp, out img, out xs, out ys);

            i = PDJPG.PDJPG_EncodeComponentCtxI2(ctx, rgba, norm, spec, luma, null, ct, xs, ys, qf, null);
            ct += i;
            return ct;
        }

        public static bool lossless=true;
        public static int quality=95;

        protected override void OnSave(Document input, Stream output, SaveConfigToken token,
            Surface scratchSurface, ProgressEventHandler callback)
        {
            RenderArgs ra = new RenderArgs(new Surface(input.Size));
            PDJPG_Context ctx;
            BytePtr obuf, ct;
            Color clr;
            BitmapLayer layer;
            Form1 settings;
            //Bitmap bmp;
            string bln;
            int xs, ys, sz;
            byte[] img;
            int i, j, lc, qf, qf1;
            //bool lossless;

            input.Render(ra, false);

            settings=new Form1();
            settings.Visible = true;
            settings.SetQuality(quality);
            settings.SetLossless(lossless);

            Application.Run(settings);

            quality = settings.quality;
            lossless = settings.lossless;

            if (settings.canceled)
            {
                //better way to do this?...
                throw new Exception();
            }

            xs = ra.Bitmap.Width;
            ys = ra.Bitmap.Height;
            img = new byte[xs * ys * 4];

            for (i = 0; i < ys; i++)
                for (j = 0; j < xs; j++)
                {
                    clr = ra.Bitmap.GetPixel(j, ys - i - 1);
                    img[(i * xs + j) * 4 + 0] = clr.R;
                    img[(i * xs + j) * 4 + 1] = clr.G;
                    img[(i * xs + j) * 4 + 2] = clr.B;
                    img[(i * xs + j) * 4 + 3] = clr.A;
                }

#if false
            for (i = 0; i < ys; i++)
                for (j = 0; j < xs; j++)
                {
                    img[(i * xs + j) * 4 + 0] = (byte)(((i & 3) == 0) ? 255 : 0);
                    img[(i * xs + j) * 4 + 1] = (byte)((((i + j) & 3) == 0) ? 255 : 0);
                    img[(i * xs + j) * 4 + 2] = (byte)(((j & 3) == 0) ? 255 : 0);
                    img[(i * xs + j) * 4 + 3] = 255;
                }
#endif
#if true
            lc = 0; bln = null;
            for (i = 0; i < input.Layers.Count; i++)
            {
                layer = (BitmapLayer)input.Layers[i];
                if (layer.Name.Contains("::"))
                    continue;
                bln = layer.Name;
                lc++;
            }
#endif

            //lossless = true;
            //qf=lossless?(100|PDJPG.PDJPG_QFL_LOSSLESS):95;
            qf=lossless?(100|PDJPG.PDJPG_QFL_LOSSLESS):quality;

            if (Form1.useRDCT)
                qf |= PDJPG.PDJPG_QFL_RDCT;
            if (Form1.use444)
                qf |= PDJPG.PDJPG_QFL_444;
            if (Form1.useRCT)
                qf |= PDJPG.PDJPG_QFL_ORCT;
            if (Form1.useRGB)
                qf |= PDJPG.PDJPG_QFL_RGB;
            if (Form1.useMegablock)
                qf |= PDJPG.PDJPG_QFL_MEGABLOCK;
            if (Form1.useAltVLC)
                qf |= PDJPG.PDJPG_QFL_ALTVLC;

            //obuf = new BytePtr(xs * ys * 4);
            obuf = new BytePtr(1 << 24);
            //            sz = PDJPG.PDJPG_Encode(img, obuf, xs, ys, 90);
//            sz = PDJPG.PDJPG_EncodeComponent(img, null, null, null, obuf, xs, ys, 95);

#if true
            ctx = PDJPG.PDJPG_AllocContext();
            ct = obuf;

            ct = PDJPG.PDJPG_EncodeBeginLayeredCtx(ctx, ct, xs, ys, qf);
            //j = (lc > 1) ? 75 : 95;
            //i = PDJPG.PDJPG_EncodeComponentCtxI2(ctx, img, null, null, null, null, ct, xs, ys, j, null);
            //i = PDJPG.PDJPG_EncodeComponentCtxI2(ctx, img, null, null, null, null, ct, xs, ys, 95, null);
            //ct += i;

#if true
            if (lc > 1)
            {
                //i = PDJPG_EncodeCtx(ctx, img, ct, xs, ys, 75, 0);
                //i = PDJPG.PDJPG_EncodeComponentCtxI2(ctx, img, null, null, null, null, ct, xs, ys, 85, null);

                qf1 = qf;

                if (lossless && Form1.useLossyBase)
                {
                    qf1 = quality;

                    if (Form1.useRDCT)
                        qf1 |= PDJPG.PDJPG_QFL_RDCT;
                    if (Form1.use444)
                        qf1 |= PDJPG.PDJPG_QFL_444;
                    if (Form1.useRCT)
                        qf1 |= PDJPG.PDJPG_QFL_ORCT;
                    if (Form1.useRGB)
                        qf1 |= PDJPG.PDJPG_QFL_RGB;
                }

                i = PDJPG.PDJPG_EncodeComponentCtxI2(ctx, img, null, null, null, null, ct, xs, ys, qf1, null);
                ct += i;

                for (i = 0; i < input.Layers.Count; i++)
                {
                    layer = (BitmapLayer)input.Layers[i];
                    if (layer.Name.Contains("::"))
                        continue;
                    qf1 = qf;
                    if (!layer.Visible)
                        qf1 |= PDJPG.PDJPG_QFL_LAYER_HIDDEN;
                    ct = EmitDocumentTagLayer(input, ctx, ct, layer.Name, i, qf1);
                }
            }
            else
            {
                ct = EmitDocumentBaseLayer(input, ctx, ct, bln, qf);
                //i = PDJPG.PDJPG_EncodeComponentCtxI2(ctx, img, null, null, null, null, ct, xs, ys, 95, null);
                //ct += i;
            }
#endif

            ct = PDJPG.PDJPG_EncodeEndLayeredCtx(ctx, ct);

            PDJPG.PDJPG_FreeContext(ctx);
            //free(tbuf);
            sz = (ct - obuf);
#endif

            if (sz > 0)
            {
                output.Write(obuf.buf, 0, sz);
            }
            else
            {
                MessageBox.Show("Encode Failed");
            }

//            ra.Bitmap.Save(output, ImageFormat.Bmp);
          
        }
    }

    public class MyFileTypeFactory : IFileTypeFactory
    {
        public FileType[] GetFileTypeInstances()
        {
            return new FileType[] { new MyFileType() };
        }
    }
}
